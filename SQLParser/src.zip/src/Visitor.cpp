
#include "Visitor.h"
#include "AST.h"

// Visitor methods implementation can be added here if needed.
